<?php $__env->startSection('temp'); ?>
<?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if (isset($component)) { $__componentOriginale180d6e92fe87517f748327e155f32bc7fdbab62 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Jobpost::class, ['job' => json_encode($job)]); ?>
<?php $component->withName('jobpost'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale180d6e92fe87517f748327e155f32bc7fdbab62)): ?>
<?php $component = $__componentOriginale180d6e92fe87517f748327e155f32bc7fdbab62; ?>
<?php unset($__componentOriginale180d6e92fe87517f748327e155f32bc7fdbab62); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h5 class="noposts">You don't have any job postings.</h5>
<?php endif; ?>
  </div>
  </div>

  <tr class="pageRow">
    <td colspan="3">
       <div class="d-flex justify-content-center pt-4">
      <?php echo e($jobs->links()); ?>

    </div>
  </td>
<?php $__env->stopSection(); ?><?php /**PATH C:\Laravel8\JobApplicationLaravel\resources\views/hirer/dashboard_temp.blade.php ENDPATH**/ ?>