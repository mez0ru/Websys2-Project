<?php $__env->startSection('Nav Menu'); ?>
<a class="nav-link" href="<?php echo e(route('jobs.index')); ?>">
    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
    Dashboard
</a>
<a class="nav-link" href="<?php echo e(route('qualifications.index')); ?>">
    Qualifications
</a>
    <div class="sb-sidenav-menu-heading">Addons</div>
    <a class="nav-link" href="report.php">
        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
        Statistics
    </a>
<?php $__env->stopSection(); ?><?php /**PATH C:\Laravel8\JobApplicationLaravel\resources\views/layouts/hirer_nav.blade.php ENDPATH**/ ?>