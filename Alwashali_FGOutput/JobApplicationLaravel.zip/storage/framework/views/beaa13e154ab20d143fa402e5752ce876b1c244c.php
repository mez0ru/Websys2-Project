


<?php $__env->startSection('title'); ?>
    Qualifications
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Qualifications</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Enhance your competence when you apply for a job by adding your qualifications you deserve here</li>
    </ol>
    
    <?php if(Session::has('delete')): ?>
    <div class="alert alert-danger deletealert" role="alert">
      <?php echo e(Session::get('delete')); ?>

    </div>
    <?php elseif(Session::has('add')): ?>
    <div class="alert alert-primary addalert" role="alert"><?php echo e(Session::get('add')); ?></div>
    <?php elseif(Session::has('edit')): ?>
    <div class="alert alert-info editalert" role="alert"><?php echo e(Session::get('edit')); ?></div>
    <?php endif; ?>

    <div class="d-grid gap-2">
      <a type="button" class="btn btn-primary" href="<?php echo e(route('qualifications.create')); ?>">Add Qualification</a>
    </div>
    
    <table class="table mt-5">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Qualification</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($qualification->id); ?></th>
            <td><?php echo e($qualification->qualification); ?></td>
            <td>
                <a type="button" class="btn btn-info" href="<?php echo e(route('qualifications.edit', $qualification->id)); ?>">Edit</a>
                <form action="<?php echo e(route('qualifications.destroy', $qualification->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Delete</button>
                </form></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <tr class="pageRow">
        <td colspan="3">
           <div class="d-flex justify-content-center pt-4">
          <?php echo e($qualifications->links()); ?>

        </div>
      </td>

            
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hirer_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel8\JobApplicationLaravel\resources\views/candidate/qualifications.blade.php ENDPATH**/ ?>